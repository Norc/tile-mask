# FVTT - Tile Mask Option
Simple module that will allow mask to be implemented. 
