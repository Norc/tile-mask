

class tileMaskIcons {
    
    static addTokenMaskButton(app, html, data) {
        html.find('.col.left').append(
            '<div class="control-icon activate-mask">\
            <img src="modules/tile-mask/images/mask.svg" width="36" height="36"></div>', 
            '<div class="control-icon activate-inversemask">\
            <img src="modules/tile-inverse-mask/images/inversemask.svg" width="36" height="36"></div>', 
            '<div class="control-icon radiusTool"><input id="myInputRadius" type="text" value="20"></div>',
            '<div class="control-icon blurTool"><input id="myInputBlur" type="text" value="20"></div>'
        );
	}
}
//********************************************************************************//
//Button For the Mask Icons// This sets a flag //
class maskActiveButton {
    
    
    
    static activateMaskButton(app, html, data) {
         
        let Tiles = canvas.tiles.get(data['_id']); 
        
            
        html.find(".activate-mask").click(() => {
        
           if (Tiles.getFlag("tile-mask","activateMask")=== undefined && Tiles.getFlag("tile-mask","activateMaskInverse")=== undefined) {
               Tiles.setFlag("tile-mask", "activateMask", true);
           } else {
                Tiles.unsetFlag("tile-mask", "activateMask");
           }
               // console.log("Check the Flag", Tiles.data.flags);
       }); 
    
        
        html.find(".activate-inversemask").click(() => {

            if (Tiles.getFlag("tile-mask","activateMaskInverse") === undefined && Tiles.getFlag("tile-mask","activateMask")=== undefined) {
                Tiles.setFlag("tile-mask", "activateMaskInverse", true);  
            }else{
                Tiles.unsetFlag("tile-mask", "activateMaskInverse");
            }
              //  console.log("Check the Flag", Tiles.data.flags);
        }); 
    }  
}

//*****************************************************************************//








class tilemask {   
    
    static search(app, html, data) {
            
        var Tiles = canvas.tiles.objects.children;
        console.log(Tiles.length);
        for (var i = 0; i<Tiles.length;i++) {
        var Tilesubject = Tiles[i];
//        var radius = Math.floor(document.getElementById("myInputRadius").value);
//        var blurSize = Math.floor(document.getElementById("myInputBlur").value);
        
        
        
//        var Tiles = canvas.scene.data.tiles;
//        //console.log(Tiles.length);
//        for (var i = 0; i<Tiles.length;i++) {
//        var Tilesubject = Tiles[i];
//        let TileS = Tilesubject._id;

                    
            if (Tilesubject.data.flags["tile-mask"]["activateMask"]===true) {
            console.log("This Tile has Mask", Tilesubject.data);
   
                    
//        var radius = 20;
//        var blurSize = 20;
//
//                const sqH = Tilesubject.data.height;
//                const sqW = Tilesubject.data.width;
//                const sqHr = (sqH * 2) + radius;
//                const sqWr = (sqW * 2) + radius;
//
//
//
//                setup();
//                function setup(loader, resources) {
//
//                    const circle = new PIXI.Graphics()
//                        .beginFill(0xFF0000)
//                        .drawCircle(sqWr / 2, sqHr / 2, radius * 10)
//                        .endFill();
//
//                    circle.filters = [new PIXI.filters.BlurFilter(blurSize)];
//
//                    //(x, y, width, height)
//                    const bounds = new PIXI.Rectangle(0, 0, sqWr * 2, sqHr * 2);
//                    const texture = canvas.app.renderer.generateTexture(circle, PIXI.SCALE_MODES.NEAREST, 1, bounds);
//                    const focus = new PIXI.Sprite(texture);
//
//                    focus["id"]= Tilesubject.data["_id"] + "_mask";
//                    focus.x = Tilesubject.data.x;
//                    focus.y = Tilesubject.data.y;
//                   console.log("hello", Tilesubject);
//                  let masked_image = Tilesubject;
//                    console.log("This is the Tile to Mask", masked_image);
//                    //This is the Mask Object
//                    let maskeffect = masked_image.children.find(x => x.id === (Tilesubject.data["_id"] + "_mask"));
//
//
//                    masked_image.x = data.x;
//                    masked_image.y = data.y;
//                    masked_image.z = data.z;   
//                    
//                    masked_image.addChild(focus);
//                    //masked_image.mask = focus; 
//
////                    if ( maskeffect === undefined) {
////                    masked_image.addChild(focus);
////                    masked_image.mask = focus; 
////                    masked_image.isMask = true;
////                    console.log("Mask has been Applied");
////
////                    } 
////
////                    else {
////                    maskeffect.destroy(true, true, true);
////                    masked_image._mask = null; //Mask cache store on Tile
////                    masked_image.isMask = false; //unused flag for mask 
////                    console.log("Mask has been Removed");
////                    console.log("Is the Mask Applied to the Tile?",masked_image.isMask);
////                    }  
////
////                    function pointerMove(event) {            
////                    focus.position.x = event.data.getLocalPosition(masked_image)["x"] - (sqWr / 2);
////                    focus.position.y = event.data.getLocalPosition(masked_image)["y"] - (sqHr / 2); 
////                    }
////
////                    if(masked_image.isMask === true ){ 
////                    masked_image.on('mousemove', pointerMove );
////                    console.log("Is the Mask Applied to the Tile?" ,masked_image.isMask) ;   
////                    }
////                    else{masked_image.off('mousemove');  
////                    }         
//                } 
            
                
            }
//            if (Tilesubject.data.flags["tile-mask"]["activateMaskInverse"]===true) {
//            console.log("This Tile has Inverse Mask", Tilesubject);
// 
//            } 
        }
    }; 
}



/*
    static activateMask(app, html, data) {
        
            var radius = Math.floor(document.getElementById("myInputRadius").value);
            var blurSize = Math.floor(document.getElementById("myInputBlur").value);
            const sqH = data.height;
            const sqW = data.width;
            const sqHr = (sqH * 2) + radius;
            const sqWr = (sqW * 2) + radius;

            setup();
            function setup(loader, resources) {

                const circle = new PIXI.Graphics()
                    .beginFill(0xFF0000)
                    .drawCircle(sqWr / 2, sqHr / 2, radius * 10)
                    .endFill();
                
                circle.filters = [new PIXI.filters.BlurFilter(blurSize)];

                //(x, y, width, height)
                const bounds = new PIXI.Rectangle(0, 0, sqWr * 2, sqHr * 2);
                const texture = canvas.app.renderer.generateTexture(circle, PIXI.SCALE_MODES.NEAREST, 1, bounds);
                const focus = new PIXI.Sprite(texture);

                focus["id"]= data["_id"] + "_mask";
                focus.x = data.x;
                focus.y = data.y;

                let masked_image = canvas.tiles.get(data['_id']);
                console.log("This is the Tile to Mask", masked_image);
                //This is the Mask Object
                let maskeffect = masked_image.children.find(x => x.id === (data["_id"] + "_mask"));
                 

                masked_image.x = data.x;
                masked_image.y = data.y;
                masked_image.z = data.z;   
   

                if ( maskeffect === undefined) {
                masked_image.addChild(focus);
                masked_image.mask = focus; 
                masked_image.isMask = true;
                console.log("Mask has been Applied");
                
                } 

                else {
                maskeffect.destroy(true, true, true);
                masked_image._mask = null; //Mask cache store on Tile
                masked_image.isMask = false; //unused flag for mask 
                console.log("Mask has been Removed");
                console.log("Is the Mask Applied to the Tile?",masked_image.isMask);
                }  

                function pointerMove(event) {            
                focus.position.x = event.data.getLocalPosition(masked_image)["x"] - (sqWr / 2);
                focus.position.y = event.data.getLocalPosition(masked_image)["y"] - (sqHr / 2); 
                }

                if(masked_image.isMask === true ){ 
                masked_image.on('mousemove', pointerMove );
                console.log("Is the Mask Applied to the Tile?" ,masked_image.isMask) ;   
                }
                else{masked_image.off('mousemove');  
                }         
            }  
        } 
}

    	static activateInverse(app, html, data) {
		console.log('TileInverseMaskIcons.activate()');
		html.find('.activate-inversemask').click(() => {
			console.log("clicked");
			console.log("data", data);
			const radius = 150;
			const blurSize = 60;
			const sqHr = (data.height + radius) * 2;
			const sqWr = (data.width  + radius) * 2;

			const mask_id = data['_id'] + '_masklayer';
			canvas.app.loader.add(mask_id, data.img);
			canvas.app.loader.load(setup);
            let imageCopy = canvas.tiles.get(data['_id']);
            let iW = imageCopy.width;
            let iH = imageCopy.height;
			
         
			function setup(loader, resources) {

				const mask_layer = new PIXI.Sprite(resources[mask_id].texture);
				mask_layer.id = data['_id'] + '_masklayer';
				
                mask_layer.rotation = data.rotation * Math.PI / 180; 
                
                mask_layer.anchor.set(0.5, 0.5);
                console.log("this is the rotation",mask_layer.rotation);
                
			         mask_layer.x = data.width/2 ;
				     mask_layer.y = data.height/2 ;	    

				mask_layer.width = data.width;
				mask_layer.height = data.height;
                console.log("width", data.width);
                canvas.fxmaster.addChild(mask_layer);
                
                const maskContainer = new PIXI.Container(mask_layer);
                maskContainer.id = data['_id'] + '_maskContainer';
                maskContainer.x = imageCopy.x;
                maskContainer.y = imageCopy.y;
                
                maskContainer.addChild(mask_layer);
                
               //maskContainer.interactive = true;
                canvas.fxmaster.addChild(maskContainer);
                

				const maskGraphic = new PIXI.Graphics();

				maskGraphic.beginFill(0xFF0000);
				maskGraphic.drawRect(0, 0, sqWr, sqHr);
				maskGraphic.beginHole();
				maskGraphic.drawCircle(sqWr / 2, sqHr / 2, radius);
				maskGraphic.endHole();
				maskGraphic.endFill();

				maskGraphic.filters = [new PIXI.filters.BlurFilter(blurSize)];

				const texture = canvas.app.renderer.generateTexture(maskGraphic);

				// create a new Sprite using the texture
				const inverse_mask = new PIXI.Sprite(texture);
				inverse_mask.id = data['_id'] + '_inversemask';
				inverse_mask.position.x = data.x + (sqWr/2);
				inverse_mask.position.y = data.y + (sqHr/2);
				inverse_mask.position.rotation = data.rotation;

				imageCopy.addChild(inverse_mask);
                imageCopy.tile.visible = false;
				
                
            function pointerMove(event) {            
                    inverse_mask.position.x = event.data.getLocalPosition(imageCopy)["x"] - (sqWr / 2);
                    inverse_mask.position.y = event.data.getLocalPosition(imageCopy)["y"] - (sqHr / 2); 
             }     
                          
                imageCopy.on('mousemove', pointerMove);
				mask_layer.mask = inverse_mask;
             
			}
		});
	}

}
*/

    
Hooks.on('ready', () => {
    if (game.user.isGM) {
        Hooks.on('renderTileHUD', (app, html, data) => {
            tileMaskIcons.addTokenMaskButton(app, html, data),
            maskActiveButton.activateMaskButton(app, html, data)

            
        });
        
    }
});

//Hooks.on("deleteTile", (app, html) => {
//console.log("this is the Tile", Tile);
//canvas.fxmaster.children.find(x=>x.id=== html["_id"]+"_maskContainer").destroy();
//});

Hooks.on ("updateTile", (app, html, data) => {
tilemask.search(app, html, data)



});

console.log("Tile Mask Icon Loaded");