








class tileMaskIcons {
    
    static addTokenMaskButton(app, html, data) {
        html.find('.col.left').append(
            '<div class="control-icon activate-mask">\
            <img src="modules/tile-mask/images/mask.svg" width="36" height="36"></div>', 
            '<div class="control-icon activate-inversemask">\
            <img src="modules/tile-inverse-mask/images/inversemask.svg" width="36" height="36"></div>', 
            '<div class="control-icon radiusTool"><input id="myInputRadius" type="text" value="20"></div>',
            '<div class="control-icon blurTool"><input id="myInputBlur" type="text" value="20"></div>'
        );
	}
}
//********************************************************************************//
//Button For the Mask Icons// This sets a flag //
//class maskActiveButton {
//    
//    static activateMask(app, html, data) {
//        
//        html.find(".activate-mask").click(() => {
//        
//           if (canvas.tiles.get(data['_id']).getFlag("tile-mask","activateMask")=== undefined) {
//            canvas.tiles.get(data['_id']).setFlag("tile-mask", "activateMask", true);  
//            }else{
//            canvas.tiles.get(data['_id']).unsetFlag("tile-mask", "activateMask");
//            }
//            console.log("flag", canvas.tiles.get(data['_id']).data.flags);
//       });
//    }
//    
//    static activateInverseMask(app, html, data) {
//
//        html.find(".activate-inversemask").click(() => {
//
//            if (canvas.tiles.get(data['_id']).getFlag("tile-mask","activateMaskInverse")=== undefined) {
//            canvas.tiles.get(data['_id']).setFlag("tile-mask", "activateMaskInverse", true);  
//            }else{
//            canvas.tiles.get(data['_id']).unsetFlag("tile-mask", "activateMaskInverse");
//            }
//            console.log("flag", canvas.tiles.get(data['_id']).data.flags);
//        });
//    }
//}

//*****************************************************************************//







class tileMasks {
    
        static activateMask(app, html, data) {
        
        html.find(".activate-mask").click(() => {
            
            var radius = Math.floor(document.getElementById("myInputRadius").value);
            var blurSize = Math.floor(document.getElementById("myInputBlur").value);
            const sqH = data.height;
            const sqW = data.width;
            const sqHr = (sqH * 2) + radius;
            const sqWr = (sqW * 2) + radius;

            setup();
            function setup(loader, resources) {

                const circle = new PIXI.Graphics()
                    .beginFill(0xFF0000)
                    .drawCircle(sqWr / 2, sqHr / 2, radius * 10)
                    .endFill();
                
                circle.filters = [new PIXI.filters.BlurFilter(blurSize)];

                //(x, y, width, height)
                const bounds = new PIXI.Rectangle(0, 0, sqWr * 2, sqHr * 2);
                const texture = canvas.app.renderer.generateTexture(circle, PIXI.SCALE_MODES.NEAREST, 1, bounds);
                const focus = new PIXI.Sprite(texture);

                focus["id"]= data["_id"] + "_mask";
                focus.position.x = 0 -(sqWr / 2);
                focus.position.y = 0 -(sqHr / 2);

                let masked_image = canvas.tiles.get(data['_id']);
                console.log("This is the Tile to Mask", masked_image);
                //This is the Mask Object
                let maskeffect = masked_image.children.find(x => x.id === (data["_id"] + "_mask"));
                 
                if ( maskeffect === undefined) {
                masked_image.addChild(focus);
                //masked_image.mask = focus; 
                masked_image.isMask = true;
                console.log("Mask has been Applied");  
                } 
                else {
                maskeffect.destroy(true, true, true);
                masked_image._mask = null; //Mask cache store on Tile
                masked_image.isMask = false; //unused flag for mask 
                console.log("Mask has been Removed");
                console.log("Is the Mask Applied to the Tile?",masked_image.isMask);
                }  

//                function pointerMove(event) {            
//                focus.position.x = event.data.getLocalPosition(masked_image)["x"] - (sqWr / 2);
//                focus.position.y = event.data.getLocalPosition(masked_image)["y"] - (sqHr / 2); 
//                }
//                var hookMember = "updateTile";
//                var functionName = "tokenMove";

                function tokenMove(app,html,data) {   
                        
                        var Tokens = canvas.tokens.ownedTokens;
                        for (var i = 0; i<Tokens.length;i++) {
                            var tokensOwned = Tokens[i];

                            if ( tokensOwned.owner === true && tokensOwned._controlled === true) { 

                                console.log("JESUS");                     
                                console.log("Uapp", app,"Uhtml", html, "Udata",data);
                                console.log(html.x, html.y);
                                focus.position.x = (-(sqWr / 2) - masked_image.x) + html.x +50;
                                focus.position.y = (-(sqHr / 2)  - masked_image.y) + html.y +50;

                                console.log("tile tracking",focus.position.x, focus.position.y, masked_image.x, masked_image.y );
                                console.log("token tracking",tokensOwned.x, tokensOwned.y);
                                console.log("update token tracking", html.x, html.y);
                            }
                        }                  
                    }          
                
                if(masked_image.isMask === true && game.user.isGM === false){ 
//                masked_image.on('mousemove', pointerMove );
                    Hooks.on('updateToken', tokenMove);
                    console.log("game user is not GM");
                    
       
//                    Hooks.on('preUpdateToken', function pointerMove(app,html,data) {            
//                    console.log("YOU SOOT");
//                    console.log("app JESUS",html);
//                }    );
//                    
                    
                    
                    
//                        Hooks.off('preUpdateToken', pointerMove);
                      //  Hooks.off('preUpdateToken', function(message){});
 

//                        Hooks.on("updateToken", (app, html, data) => {
//                            
//                            var Tokens = canvas.tokens.ownedTokens;
//                            for (var i = 0; i<Tokens.length;i++) {
//                                var tokensOwned = Tokens[i];
//                                // console.log(tokensOwned);
//
//                                if ( tokensOwned.owner === true && tokensOwned._controlled === true) { 
////                                let zoo = tokensOwned;
////                                zoo.on('mousemove', pointerMove );
//                                   console.log("JESUS");                     
//                                    console.log("Uapp", app,"Uhtml", html, "Udata",data);
//                                    console.log(html.x, html.y);
//                                focus.position.x = (-(sqWr / 2) - masked_image.x) + html.x +50;
//                                focus.position.y = (-(sqHr / 2)  - masked_image.y) + html.y +50;
//                            
//                              
//
//                                console.log("tile tracking",focus.position.x, focus.position.y, masked_image.x, masked_image.y );
//                                console.log("token tracking",tokensOwned.x, tokensOwned.y);
//                                console.log("update token tracking", html.x, html.y);
//                                }
//                                
//                                
//                                
//                            }
//                        });

                    
                    
                    
                console.log("Is the Mask Applied to the Tile?" ,masked_image.isMask) ;   
                }
                else if ( masked_image.isMask === false  ) { 
                Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.name==="tokenMove"));
                masked_image.off('mousemove');  
                }         
            }  
        });
    } 
    

    	static activateInverse(app, html, data) {
		console.log('TileInverseMaskIcons.activate()');
		html.find('.activate-inversemask').click(() => {
			console.log("clicked");
			console.log("data", data);
			const radius = 150;
			const blurSize = 60;
			const sqHr = (data.height + radius) * 2;
			const sqWr = (data.width  + radius) * 2;

			const mask_id = data['_id'] + '_masklayer';
			canvas.app.loader.add(mask_id, data.img);
			canvas.app.loader.load(setup);
            let imageCopy = canvas.tiles.get(data['_id']);
            let iW = imageCopy.width;
            let iH = imageCopy.height;
			

			function setup(loader, resources) {

				const mask_layer = new PIXI.Sprite(resources[mask_id].texture);
				mask_layer.id = data['_id'] + '_masklayer';
				
                mask_layer.rotation = data.rotation * Math.PI / 180; 
                
                mask_layer.anchor.set(0.5, 0.5);
                console.log("this is the rotation",mask_layer.rotation);
                
			         mask_layer.x = data.width/2 ;
				     mask_layer.y = data.height/2 ;	    

				mask_layer.width = data.width;
				mask_layer.height = data.height;
                console.log("width", data.width);
                canvas.fxmaster.addChild(mask_layer);
                
                const maskContainer = new PIXI.Container(mask_layer);
                maskContainer.id = data['_id'] + '_maskContainer';
                maskContainer.x = imageCopy.x;
                maskContainer.y = imageCopy.y;
                
                maskContainer.addChild(mask_layer);
                
               //maskContainer.interactive = true;
                canvas.fxmaster.addChild(maskContainer);
                
				const maskGraphic = new PIXI.Graphics();

				maskGraphic.beginFill(0xFF0000);
				maskGraphic.drawRect(0, 0, sqWr, sqHr);
				maskGraphic.beginHole();
				maskGraphic.drawCircle(sqWr / 2, sqHr / 2, radius);
				maskGraphic.endHole();
				maskGraphic.endFill();

				maskGraphic.filters = [new PIXI.filters.BlurFilter(blurSize)];

				const texture = canvas.app.renderer.generateTexture(maskGraphic);

				// create a new Sprite using the texture
				const inverse_mask = new PIXI.Sprite(texture);
				inverse_mask.id = data['_id'] + '_inversemask';
				inverse_mask.position.x = data.x + (sqWr/2);
				inverse_mask.position.y = data.y + (sqHr/2);
				inverse_mask.position.rotation = data.rotation;

				imageCopy.addChild(inverse_mask);
                imageCopy.tile.visible = false;
				
                
            function pointerMove(event) {            
                    inverse_mask.position.x = event.data.getLocalPosition(imageCopy)["x"] - (sqWr / 2);
                    inverse_mask.position.y = event.data.getLocalPosition(imageCopy)["y"] - (sqHr / 2); 
             }     
                imageCopy.on('mousemove', pointerMove);
				mask_layer.mask = inverse_mask;
             
			}
		});
	}

}


Hooks.on('ready', () => {
    if (game.user.isGM) {
        Hooks.on('renderTileHUD', (app, html, data) => {
            tileMaskIcons.addTokenMaskButton(app, html, data),
            tileMasks.activateMask(app, html, data),
            tileMasks.activateInverse(app, html, data)
//            maskActiveButton.activateMask(app, html, data)
//            maskActiveButton.activateInverseMask(app, html, data)
        });
    }
});

Hooks.on("deleteTile", (app, html) => {
console.log("this is the Tile", Tile);
canvas.fxmaster.children.find(x=>x.id=== html["_id"]+"_maskContainer").destroy();
});

console.log("Tile Mask Icon Loaded");