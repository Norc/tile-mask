//CONFIG.debug.hooks = true;
// replace tile._mask with Tile.tile._mask replace if problem persist
class TileMaskLayer extends PlaceablesLayer {
  constructor() {
    super();

    this._controlled = {};
    this.visible =true;
//    this.createmask = function setupMask(loader, resources) {

//            var Tiles = canvas.tiles.objects.children;
//              console.log(Tiles.length);
//            for (var i = 0; i<Tiles.length;i++) {
//                 var Tilesubject = Tiles[i];
//
//                 if (Tilesubject.getFlag("tile-mask","activateMaskInverse")=== true){   
//                  console.log("GET THE GUNS MAN",Tilesubject);
//                 }
//                 if (Tilesubject.getFlag("tile-mask","activateMask")=== true){
//                  console.log("GET THE GUNS MAN",Tilesubject);
//                 }
//            } 
//
//        };
 }

  static get layerOptions() {
    return mergeObject(super.layerOptions, {
      canDragCreate: false,
      objectClass: Note,
      sheetClass: NoteConfig
    });
  }   
}

Hooks.once("canvasInit", (canvas) => {
canvas.tilemaskeffect = canvas.stage.addChildAt(new TileMaskLayer(canvas), 8);
});


class Tilemask {

    
    static addTokenMaskButton(app, html, data) {
        html.find('.col.left').append(
            '<div class="control-icon activate-mask">\
            <img src="modules/tile-mask/images/mask.svg" width="36" height="36" title="Toggle Mask"></div>', 
            '<div class="control-icon activate-inversemask">\
            <img src="modules/tile-inverse-mask/images/inversemask.svg" width="36" height="36" title="Toggle Inverse Mask"></div>', 
            '<div class="control-icon radiusTool"><input id="myInputRadius" type="text" value="5" maxlength ="2" title="Circle Size"></div>',
            '<div class="control-icon blurTool"><input id="myInputBlur" type="text"  value="5" maxlength ="2" title="Blur Size"></div>',
           '<div class="control-icon activate-test">\
            <img src="modules/tile-mask/images/mask.svg" width="36" height="36" title="test"></div>'
    );}
    
    static activateMaskButton(app, html, data) {
         
        let Tile = canvas.tiles.get(data["_id"]); 
        

        function inputSize (){
        var blurSize = Math.floor(document.getElementById("myInputBlur").value);
        var radius = Math.floor(document.getElementById("myInputRadius").value);
        var myArr = [radius, blurSize];
        return myArr;
        }
        
        html.find(".activate-test").click (() => { 
            
            var inputValues = inputSize();
            console.log(inputValues);
            if (inputValues[0] > 5 || inputValues[1] > 5) 
            {
                Tile.setFlag("tile-mask", "radius", inputValues[0]);
                Tile.setFlag("tile-mask", "blur", inputValues[1]);
            } else { 
                document.getElementById("myInputBlur");
                document.getElementById("myInputRadius");
            }
        if ( Tile.getFlag("tile-mask","activateMask")=== true && inputValues[0] > 5 || inputValues[1] > 5 ){
            Tile.children.find(x => x.id === (Tile.data["_id"] + "_mask")).destroy(true,true,true);
            Tile.tile._mask = null;
            Tile.isMask = false;
            Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
            }  
        
            
        
        });
        
        if(Tile.getFlag("tile-mask", "radius")) {
            
            
        
        var dataRadius = data.flags["tile-mask"]["radius"];
        var dataBlur = data.flags["tile-mask"]["blur"];
        document.getElementById("myInputRadius").value = dataRadius;
        document.getElementById("myInputBlur").value = dataBlur; 
        }
        console.log("checking flags for this part",data.flags["tile-mask"])
      
        html.find(".activate-mask").click(() => {
                

    
           if (Tile.getFlag("tile-mask","activateMask")=== undefined
               && Tile.getFlag("tile-mask","activateMaskInverse")=== undefined) {
               
                   Tile.setFlag("tile-mask", "activateMask", true);
                   Tile.setFlag("tile-mask", "activateMaskInverse", false);

                                                                       
           } else if (Tile.getFlag("tile-mask","activateMask")=== false 
                && Tile.getFlag("tile-mask","activateMaskInverse")=== false ){
               
                   Tile.setFlag("tile-mask", "activateMask", true);
                   Tile.setFlag("tile-mask", "activateMaskInverse", false)
                                                                        
           } else {
                Tile.setFlag("tile-mask", "activateMask", false);
                Tile.setFlag("tile-mask", "activateMaskInverse", false)                                                       
           }
                                                                            //console.log("Check the Flag", Tiles.data.flags);
       }); 

        html.find(".activate-inversemask").click(() => {
            

            if (Tile.getFlag("tile-mask","activateMaskInverse") === undefined 
                && Tile.getFlag("tile-mask","activateMask")=== undefined) {
                
                    Tile.setFlag("tile-mask", "activateMaskInverse", true);
                    Tile.setFlag("tile-mask", "activateMask", false);
                                                                   
            } else if (Tile.getFlag("tile-mask","activateMaskInverse")=== false 
                && Tile.getFlag("tile-mask","activateMask")=== false){
                
                    Tile.setFlag("tile-mask", "activateMaskInverse", true);
                    Tile.setFlag("tile-mask", "activateMask", false);                
                                                                            
            }else{
                Tile.setFlag("tile-mask", "activateMaskInverse", false);
                Tile.setFlag("tile-mask", "activateMask", false);
                
                                                                            
            }
                                                                            //console.log("Check the Flag", Tiles.data.flags);
        }); 
    }  
    
    static create(app, html, data) {
        
        
    if ( canvas.tiles.objects.children.lenth ===0){
        return;

    }
    if(!data) {        // data only exist on update tile
        canvas.tiles.objects.children.forEach(init); // iterate over the Tiles array.
    }
    else {
        init();     
    }
         

    
        async function init(obj, index, array){   
            
            
                    
               
                if(!obj){
                 //console.log("YESSSS",app,html,data);
                 var Tile = canvas.tiles.get(data["_id"]); 
                 var ID = Tile.id;
                }else{
                 var Tile = canvas.tiles.get(obj.data["_id"]);     
                }
                if (Tile.getFlag("tile-mask","activateMaskInverse") === undefined 
                    && Tile.getFlag("tile-mask","activateMask")=== undefined) { 
                        console.log("no Flag");
                        return;
                } 
                  
//console.log("Look here now", Tile);  
//console.log((document.getElementById("myInputRadius").value));
//               var radius = Math.floor(document.getElementById("myInputRadius").value);
//               var blurSize = Math.floor(document.getElementById("myInputBlur").value);
               
                 console.log("hello mate",Tile.getFlag("tile-mask", "radius"),Tile.getFlag("tile-mask", "blur"));
                    
                
                
                var radius, blurSize, sqHr, sqWr;
                if (!Tile.getFlag("tile-mask", "radius")) { radius = 5* 10;
                }else { radius = Tile.getFlag("tile-mask", "radius") * 10 }
                if (!Tile.getFlag("tile-mask", "blur")) { blurSize = 5;
                }else { blurSize = Tile.getFlag("tile-mask", "blur"); } 
                console.log("rad blur", radius, blurSize);

                //console.log("rad", radius, blurSize);
                sqHr = (Tile.data.height + radius + (blurSize * 4) ) * 2 ;
                sqWr = (Tile.data.width  + radius + (blurSize * 4) ) * 2 ;
                var containerObject = await canvas.tilemaskeffect.children.find(x=>x.id===Tile.data["_id"]+"_maskContainer");
                

                
               
                function tokenMove(app,html,data) {  
                        
                        
                        var Tokens = canvas.tokens.ownedTokens;
                        for (var i = 0; i<Tokens.length;i++) {
                            var tokensOwned = Tokens[i];
                            var tokensData = tokensOwned.data;
                            var xData = tokensData.x
                            var yData = tokensData.y
                            var  hehe = canvas.tilemaskeffect.children.find(x=>x.id===Tile.data["_id"]+"_maskContainer");
                            
                            console.log("this is data of token",tokensData);
                         
                            if (Tile.data.flags["tile-mask"]["activateMask"]===true) {
                                
                                var maskObject = Tile.children.find(x=>x.id=== Tile.data["_id"]+"_mask");
                                                            
                            } else {
                                
                                var maskObject = Tile.children.find(x=>x.id=== Tile.data["_id"]+"_inversemask");
                            } 

                            if ( tokensOwned.owner === true && tokensOwned._controlled === true) { 

//                                if ( xData < Tile.data.x - ((radius + (blurSize/4)) * 1.3) ||
//                                     xData > Tile.data.x + ((sqWr / 2) - ( radius + blurSize )))          || 
//                                     yData < Tile.data.y - ((radius + (blurSize/4)) * 1.3) || 
//                                     yData > Tile.data.y + ((sqHr / 2) -( radius + blurSize ))
//                                   ){
                                //console.log("xData",xData, yData, "Tiledata",Tile.data.x,Tile.data.y);
                                
                            if ( xData < Tile.data.x  ||
                                 xData > Tile.data.x + ((sqWr / 2) - (( radius + blurSize )*1.3))          || 
                                 yData < Tile.data.y  || 
                                 yData > Tile.data.y + ((sqHr / 2) -(( radius + blurSize )*1.3))
                            ){


                                        if (maskObject.position.x !== Tile.data.x ||
                                            maskObject.position.y !== Tile.data.y) {
                                                maskObject.position.x = 0;
                                                maskObject.position.y = 0;
                                           // if  (!game.user.isGM)  hehe.alpha = 1;
                                        }
                                    
                                } else {  
                                        
                                    if (maskObject.visible !== false || Tile.isMask=== true ){
                                        maskObject.position.x = (-(sqWr / 2)  - Tile.x)+ tokensData.x +50;      
                                        maskObject.position.y = (-(sqHr / 2)  - Tile.y)+ tokensData.y +50;  
                                        //if (!game.user.isGM) hehe.alpha = 0.5;
                                    } 
//console.log("token tracking",tokensOwned.x, tokensOwned.y);
//console.log("Tile.data tracking", Tile.data.x, Tile.data.y);
//console.log("Mask tracking", maskObject.position.x, maskObject.position.y);
                                }
                            }
                        }                  
} 

                function setupMask() {
                    

                    const circle = new PIXI.Graphics()
                    .beginFill(0xFF0000)
                    .drawCircle(sqWr / 2, sqHr / 2, radius)
                    .endFill();

                    circle.filters  = [new PIXI.filters.BlurFilter(blurSize)];
                    const bounds    =  new PIXI.Rectangle(0, 0, sqWr * 2, sqHr * 2);
                    const texture   =  canvas.app.renderer.generateTexture(circle, PIXI.SCALE_MODES.NEAREST, 1, bounds);

                    const focus = new PIXI.Sprite(texture);
                    focus["id"] = Tile.data["_id"] + "_mask";
                    

                    Tile.addChild(focus);
                    Tile.tile.mask = focus; //PIXI mask Effect 
                    Tile.isMask = true;  
             
                    Hooks.on('updateToken', tokenMove);
                    tokenMove.id = Tile.data['_id'] + '_mask';
}

                function setupInverse() {


                    const imgCopy = new PIXI.Sprite(Tile.texture);

                        imgCopy.id       = Tile.data['_id'] + 'imgCopy';
                        imgCopy.rotation = Tile.data.rotation * Math.PI / 180; 
                        imgCopy.anchor.set(0.5, 0.5);

                        imgCopy.x        = Tile.data.width/2 ;
                        imgCopy.y        = Tile.data.height/2 ;	    
                        imgCopy.width    = Tile.data.width;
                        imgCopy.height   = Tile.data.height;
//console.log("width", Tile.data.width);



                    const maskContainer = new PIXI.Container(imgCopy)
                        maskContainer.name = 'maskContainer';
                        maskContainer.id   = Tile.data['_id'] + '_maskContainer';
                        maskContainer.x    = Tile.x
                        maskContainer.y    = Tile.y;
                        maskContainer.addChild(imgCopy);


                    canvas.tilemaskeffect.addChild(maskContainer);
                    
                    
                    
                    function containerMove(){

                            if (Tile.data.flags["tile-mask"]["activateMaskInverse"]=== true){
                                maskContainer.position.x = Tile.data.x;
                                maskContainer.position.y = Tile.data.y; 
                            }
                         }

                    containerMove.id = Tile.data['_id'] + '_mask'; 
                    
                    Hooks.on('updateTile', containerMove);  //add the follow token function
                    
                    
                    if (game.user.isGM) maskContainer.alpha =.25 ;

                        const maskGraphic = new PIXI.Graphics()   //The the mask object graphic -> texture -> sprite -> container = focus

                            .beginFill(0xFF0000)
                            .drawRect(0, 0, sqWr, sqHr)
                            .beginHole()
                            .drawCircle(sqWr / 2, sqHr / 2, radius)
                            .endHole()
                            .endFill();
                            maskGraphic.filters = [new PIXI.filters.BlurFilter(blurSize)];
                        const texture = canvas.app.renderer.generateTexture(maskGraphic);
                        const focus = new PIXI.Sprite(texture);
                        focus.id = Tile.data['_id'] + '_inversemask';

                        Tile.addChild(focus);

                        //if(containerObject.worldVisbile = true){ 
                            Hooks.on('updateToken', tokenMove);
                            tokenMove.id = Tile.data['_id'] + '_mask'; 
                            imgCopy.mask = focus;   //PIXI mask EFFECT  
                        //}


                        Tile.tile.visible = false;
                        
}

                function checkFlag() {

                var newTiles = canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer");  



                            if(Tile.getFlag("tile-mask","activateMaskInverse")=== false 
                            && Tile.data.flags["tile-mask"]["activateMask"] !== undefined && 
                            canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer") === undefined) {

                                if (Tile.data.flags["tile-mask"]["activateMask"]===true 
                                    && Tile.tile._mask === null) {


                                    return setupMask();
                                    

                                }

                                else if (Tile.data.flags["tile-mask"]["activateMask"]===false 
                                         && Tile.tile._mask === null && newTiles === undefined) { 

console.log("ignore");
                                            return;

                                } 

                                else if (Tile.data.flags["tile-mask"]["activateMask"]===false 
                                         && Tile.tile._mask !== null
                                        ) {

                                            Tile.children.find(x => x.id === (ID + "_mask")).destroy(true,true,true);
                                            Tile.tile._mask = null;
                                            Tile.isMask = false;
console.log("Mask has been Removed");
console.log("Is the Mask Applied to the Tile?",Tile.isMask);
                                            Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
                                    return;


                                } 


                                //return;

                            } 
                            else if (Tile.getFlag("tile-mask","activateMask")=== false 
                                     && Tile.data.flags["tile-mask"]["activateMaskInverse"] !== undefined 
                                     && Tile.tile._mask === null
                                    ){

                                        if (Tile.data.flags["tile-mask"]["activateMaskInverse"]===true &&
                                        canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer") === undefined ){

                                           return setupInverse(); 

                                        } 
                                        else if (Tile.data.flags["tile-mask"]["activateMaskInverse"]=== false) {
                                                
                                                 Hooks.off("updateTile", Hooks._hooks.updateTile.find(x=>x.id===(Tile.data['_id'] + '_mask')));
                                                 

                                                Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
                                                Tile.children.find(x=>x.id=== Tile.data["_id"]+"_inversemask").destroy();

                                            
                                                 canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer").destroy();
                                                 Tile.tile.visible = true; //returns visibility of the orginal tile
                                        }
                            }
                    
}
                
                checkFlag();
         }
    }

}

Hooks.on('ready', () => {
    if (game.user.isGM) {
        Hooks.on('renderTileHUD', (app, html, data) => {
            Tilemask.addTokenMaskButton(app, html, data),   // button display on HUD
            Tilemask.activateMaskButton(app, html, data)    // update the Tile when GM toggles Mask
           // console.log(app,html,data);
        });   
    }
   
});
Hooks.on ("updateTile", (app, html, data) => {

                   // console.log("checking at updateTile", data.flags);
            Tilemask.create(app, html, data);

//            if (data.flags === undefined){ 
//                Tilemask.create(app, html, data);
//                console.log("Moving Tile, or Creating Mask, no flag data");
                         
//            } else  {
//               // console.log("checkagain", data.flags);
//            }
   // console.log("1",app, "2",html,"3", data);
//    if(!html.flags["tile-mask"]["blur"]){
//        console.log("undefined")
//    }
    //var Tile = canvas.tiles.get(html["_id"]); 

});

Hooks.on('canvasReady', () => {
    Tilemask.create();
});

Hooks.on("preDeleteTile", (app, data) => {

let Tile = canvas.tiles.get(data["_id"]);
if (Tile.getFlag("tile-mask","activateMaskInverse")=== undefined && Tile.getFlag("tile-mask","activateMask")=== undefined){
    return;
}

if (Tile.getFlag("tile-mask","activateMaskInverse")=== true && canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer") ){
    
    canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer").destroy();   // the imgCopy of Tile
    Hooks.off("updateTile", Hooks._hooks.updateTile.find(x=>x.id===(Tile.data['_id'] + '_mask'))); //removes the caches
    

        Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
       // console.log("Hook removed from token") //removes the caches


} else if ( Tile.getFlag("tile-mask","activateMask")=== true && Tile.tile._mask !==null
){
    Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask"))); //removes the hook function to follow token
}

});


console.log("Tile Mask Icon Loaded");