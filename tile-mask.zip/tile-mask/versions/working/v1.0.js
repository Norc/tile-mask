//CONFIG.debug.hooks = true;
// replace tile._mask with Tile.tile._mask replace if problem persist
class TileMaskLayer extends PlaceablesLayer {
  constructor() {
    super();

    this._controlled = {};
    this.visible =true;
//    this.createmask = function setupMask(loader, resources) {

//            var Tiles = canvas.tiles.objects.children;
//              console.log(Tiles.length);
//            for (var i = 0; i<Tiles.length;i++) {
//                 var Tilesubject = Tiles[i];
//
//                 if (Tilesubject.getFlag("tile-mask","activateMaskInverse")=== true){   
//                  console.log("GET THE GUNS MAN",Tilesubject);
//                 }
//                 if (Tilesubject.getFlag("tile-mask","activateMask")=== true){
//                  console.log("GET THE GUNS MAN",Tilesubject);
//                 }
//            } 
//
//        };
 }

  static get layerOptions() {
    return mergeObject(super.layerOptions, {
      canDragCreate: false,
      objectClass: Note,
      sheetClass: NoteConfig
    });
  }   
}

Hooks.once("canvasInit", (canvas) => {
canvas.tilemaskeffect = canvas.stage.addChildAt(new TileMaskLayer(canvas), 8);
});


class Tilemask {  
    
    
    static addTokenMaskButton(app, html, data) {
        html.find('.col.left').append(
            '<div class="control-icon activate-mask">\
            <img src="modules/tile-mask/images/mask.svg" width="36" height="36"></div>', 
            '<div class="control-icon activate-inversemask">\
            <img src="modules/tile-inverse-mask/images/inversemask.svg" width="36" height="36"></div>', 
            '<div class="control-icon radiusTool"><input id="myInputRadius" type="text" value="20"></div>',
            '<div class="control-icon blurTool"><input id="myInputBlur" type="text" value="5"></div>'
    );}
    
    static activateMaskButton(app, html, data) {
         
        
        var Tile = canvas.tiles.get(data["_id"]); 
    
        html.find(".activate-mask").click(() => {
        
           if (Tile.getFlag("tile-mask","activateMask")=== undefined
               && Tile.getFlag("tile-mask","activateMaskInverse")=== undefined) {
               
                   Tile.setFlag("tile-mask", "activateMask", true);
                   Tile.setFlag("tile-mask", "activateMaskInverse", false);

                                                                            
           } else if (Tile.getFlag("tile-mask","activateMask")=== false 
                && Tile.getFlag("tile-mask","activateMaskInverse")=== false ){
               
                   Tile.setFlag("tile-mask", "activateMask", true);
                   Tile.setFlag("tile-mask", "activateMaskInverse", false)
                                                                            
           } else {
                Tile.setFlag("tile-mask", "activateMask", false);
                Tile.setFlag("tile-mask", "activateMaskInverse", false)                                                       
           }
                                                                            //console.log("Check the Flag", Tiles.data.flags);
       }); 

        html.find(".activate-inversemask").click(() => {

            if (Tile.getFlag("tile-mask","activateMaskInverse") === undefined 
                && Tile.getFlag("tile-mask","activateMask")=== undefined) {
                
                    Tile.setFlag("tile-mask", "activateMaskInverse", true);
                    Tile.setFlag("tile-mask", "activateMask", false)
                    
                                                                            
            } else if (Tile.getFlag("tile-mask","activateMaskInverse")=== false 
                && Tile.getFlag("tile-mask","activateMask")=== false){
                
                    Tile.setFlag("tile-mask", "activateMaskInverse", true);
                    Tile.setFlag("tile-mask", "activateMask", false);
                    
                                                                            
            }else{
                Tile.setFlag("tile-mask", "activateMaskInverse", false);
                Tile.setFlag("tile-mask", "activateMask", false);
                
                                                                            
            }
                                                                            //console.log("Check the Flag", Tiles.data.flags);
        }); 
    }  
    
    static create(app, html, data) {
        
    if ( canvas.tiles.objects.children.lenth ===0){
        return;

    }
    if(!data) {        
        canvas.tiles.objects.children.forEach(init);
    }
    else {
        init();
    }

           function init(obj, index, array){
               
                if(!obj){
                 //console.log("YESSSS",app,html,data);
                 var Tile = canvas.tiles.get(data["_id"]); 
                 var ID = Tile.id;
                }else{
                 var Tile = canvas.tiles.get(obj.data["_id"]);     
                }
                if (Tile.getFlag("tile-mask","activateMaskInverse") === undefined 
                    && Tile.getFlag("tile-mask","activateMask")=== undefined) { 
                        console.log("no Flag");
                        return;
                } 
                  
//console.log("Look here now", Tile);  
//console.log((document.getElementById("myInputRadius").value));
//               var radius = Math.floor(document.getElementById("myInputRadius").value);
//               var blurSize = Math.floor(document.getElementById("myInputBlur").value);
               
//               
                var radius, blurSize, sqHr, sqWr;
                radius = 20 * 10;
                blurSize = 20;
                sqHr = (Tile.data.height + radius + (blurSize * 4) ) * 2 ;
                sqWr = (Tile.data.width  + radius + (blurSize * 4) ) * 2 ;
            
                function tokenMove(app,html,data) {  
                        
     
                        var Tokens = canvas.tokens.ownedTokens;
                        for (var i = 0; i<Tokens.length;i++) {
                            var tokensOwned = Tokens[i];
                            var tokensData = tokensOwned.data;
                            var xData = tokensData.x
                            var yData = tokensData.y

                            if (Tile.data.flags["tile-mask"]["activateMask"]===true) {
                                
                                var maskObject = Tile.children.find(x=>x.id=== Tile.data["_id"]+"_mask");
                                                            
                            } else {
                                
                                var maskObject = Tile.children.find(x=>x.id=== Tile.data["_id"]+"_inversemask");
                            } 

                            if ( tokensOwned.owner === true && tokensOwned._controlled === true) { 

                                if ( xData < Tile.data.x - ((radius + (blurSize/4)) * 1.3) ||
                                     xData > Tile.data.x + ((sqWr / 2) - ( radius + blurSize ))          || 
                                     yData < Tile.data.y - ((radius + (blurSize/4)) * 1.3) || 
                                     yData > Tile.data.y + ((sqHr / 2) -( radius + blurSize ))
                                   ){

                                        if (maskObject.position.x !== Tile.data.x ||
                                            maskObject.position.y !== Tile.data.y) {
                                                maskObject.position.x = 0;
                                                maskObject.position.y = 0;
                                        }
                                    
                                } else {  

                                    if (maskObject.visible !== false || Tile.isMask=== true ){
                                        maskObject.position.x = (-(sqWr / 2)  - Tile.x)+ tokensData.x +50;      
                                        maskObject.position.y = (-(sqHr / 2)  - Tile.y)+ tokensData.y +50;  
                                    } 
//console.log("token tracking",tokensOwned.x, tokensOwned.y);
//console.log("Tile.data tracking", Tile.data.x, Tile.data.y);
//console.log("Mask tracking", maskObject.position.x, maskObject.position.y);
                                }
                            }
                        }                  
} 

                function setupMask() {
                    

                    const circle = new PIXI.Graphics()
                    .beginFill(0xFF0000)
                    .drawCircle(sqWr / 2, sqHr / 2, radius)
                    .endFill();

                    circle.filters  = [new PIXI.filters.BlurFilter(blurSize)];
                    const bounds    =  new PIXI.Rectangle(0, 0, sqWr * 2, sqHr * 2);
                    const texture   =  canvas.app.renderer.generateTexture(circle, PIXI.SCALE_MODES.NEAREST, 1, bounds);

                    const focus = new PIXI.Sprite(texture);
                    focus["id"] = Tile.data["_id"] + "_mask";
                    

                    Tile.addChild(focus);
                    Tile.tile.mask = focus; //PIXI mask Effect 
                    Tile.isMask = true;  
             
                    Hooks.on('updateToken', tokenMove);
                    tokenMove.id = Tile.data['_id'] + '_mask';
}

                function setupInverse() {


                    const imgCopy = new PIXI.Sprite(Tile.texture);

                        imgCopy.id       = Tile.data['_id'] + 'imgCopy';
                        imgCopy.rotation = Tile.data.rotation * Math.PI / 180; 
                        imgCopy.anchor.set(0.5, 0.5);

                        imgCopy.x        = Tile.data.width/2 ;
                        imgCopy.y        = Tile.data.height/2 ;	    
                        imgCopy.width    = Tile.data.width;
                        imgCopy.height   = Tile.data.height;
//console.log("width", Tile.data.width);



                    const maskContainer = new PIXI.Container(imgCopy)
                        maskContainer.name = 'maskContainer';
                        maskContainer.id   = Tile.data['_id'] + '_maskContainer';
                        maskContainer.x    = Tile.x
                        maskContainer.y    = Tile.y;
                        maskContainer.addChild(imgCopy);


                    canvas.tilemaskeffect.addChild(maskContainer);

                    const maskGraphic = new PIXI.Graphics()

                        .beginFill(0xFF0000)
                        .drawRect(0, 0, sqWr, sqHr)
                        .beginHole()
                        .drawCircle(sqWr / 2, sqHr / 2, radius)
                        .endHole()
                        .endFill();
                        maskGraphic.filters = [new PIXI.filters.BlurFilter(blurSize)];

                    const texture = canvas.app.renderer.generateTexture(maskGraphic);

                    // create a new Sprite using the texture
                    const focus = new PIXI.Sprite(texture);
                    focus.id = Tile.data['_id'] + '_inversemask';
                    
                    
                    

                    Tile.addChild(focus);
                    Tile.tile.visible = false;
                    

                    function containerMove(){
                       
                        if (Tile.data.flags["tile-mask"]["activateMaskInverse"]=== true){
                            maskContainer.position.x = Tile.data.x;
                            maskContainer.position.y = Tile.data.y; 
                        }
                     }

                     containerMove.id = Tile.data['_id'] + '_mask';
                    var containerObject = canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer");
                    if(containerObject.worldVisbile = true){ 
                        Hooks.on('updateTile', containerMove);


                        Hooks.on('updateToken', tokenMove);
                        tokenMove.id = Tile.data['_id'] + '_mask';
                        

                    
                        
                    }

//console.log("Is the Inversed Mask Applied to the Tile?" , maskContainer) ; 
                    imgCopy.mask = focus;  //PIXI mask EFFECT        
}

                function checkFlag() {

                var newTiles = canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer");  



                            if(Tile.getFlag("tile-mask","activateMaskInverse")=== false 
                            && Tile.data.flags["tile-mask"]["activateMask"] !== undefined && 
                            canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer") === undefined) {

                                if (Tile.data.flags["tile-mask"]["activateMask"]===true 
                                    && Tile.tile._mask === null) {


                                    return setupMask();
                                    

                                }

                                else if (Tile.data.flags["tile-mask"]["activateMask"]===false 
                                         && Tile.tile._mask === null && newTiles === undefined) { 

console.log("ignore");
                                            return;

                                } 

                                else if (Tile.data.flags["tile-mask"]["activateMask"]===false 
                                         && Tile.tile._mask !== null
                                        ) {

                                            Tile.children.find(x => x.id === (ID + "_mask")).destroy(true,true,true);
                                            Tile.tile._mask = null;
                                            Tile.isMask = false;
console.log("Mask has been Removed");
console.log("Is the Mask Applied to the Tile?",Tile.isMask);
                                            Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
                                    return;


                                } 


                                //return;

                            } 
                            else if (Tile.getFlag("tile-mask","activateMask")=== false 
                                     && Tile.data.flags["tile-mask"]["activateMaskInverse"] !== undefined 
                                     && Tile.tile._mask === null
                                    ){

                                        if (Tile.data.flags["tile-mask"]["activateMaskInverse"]===true &&
                                        canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer") === undefined ){

                                           return setupInverse(); 

                                        } 
                                        else if (Tile.data.flags["tile-mask"]["activateMaskInverse"]=== false) {

                                                 Hooks.off("updateTile", Hooks._hooks.updateTile.find(x=>x.id===(Tile.data['_id'] + '_mask')));
                                                 Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
                                                 Tile.children.find(x=>x.id=== Tile.data["_id"]+"_inversemask").destroy();
                                                 canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer").destroy();
                                                 Tile.tile.visible = true;
                                        }
                            }
                    
}
                
                checkFlag();
         }
    }

}

Hooks.on('ready', () => {
    if (game.user.isGM) {
        Hooks.on('renderTileHUD', (app, html, data) => {
            Tilemask.addTokenMaskButton(app, html, data),
            Tilemask.activateMaskButton(app, html, data)
            
        });   
    }
   
});
Hooks.on ("updateTile", (app, html, data) => {
                Tilemask.create(app, html, data)
      
});

Hooks.on('canvasReady', () => {
    Tilemask.create();
});

Hooks.on("preDeleteTile", (app, data) => {

let Tile = canvas.tiles.get(data["_id"]);

if (Tile.getFlag("tile-mask","activateMaskInverse")=== true && canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer") ){
    
    canvas.tilemaskeffect.children.find(x=>x.id=== Tile.data["_id"]+"_maskContainer").destroy();
    Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
    Hooks.off("updateTile", Hooks._hooks.updateTile.find(x=>x.id===(Tile.data['_id'] + '_mask'))); 
    console.log("Hook removed from token")
    
} else if ( Tile.getFlag("tile-mask","activateMask")=== true && Tile.tile._mask !==null
){
    Hooks.off("updateToken", Hooks._hooks.updateToken.find(x=>x.id===(Tile.data["_id"] + "_mask")));
}

});


console.log("Tile Mask Icon Loaded");